#include<stdio.h>
#include<conio.h>
void main()
{
int a,b,c,d,e;
float perc;
clrscr();
printf("enter marks of 5 subjects");
scanf("%d %d %d %d %d",&a,&b,&c,&d,&e);
perc=(a+b+c+d+e)/5;
if(perc>90 && perc<=100){
printf("A");}
else if(perc>80 && perc<=90){
printf("B");}
else if(perc>60 && perc<=80){
printf("C");}
else{
printf("D");}
getch();
}