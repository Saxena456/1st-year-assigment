#include<stdio.h>
#include<conio.h>
void main()
{
int a[10],j,sum=0;
clrscr();
printf("enter the numbers");

for( j=0;j<10;j++)
{ scanf("%d",&a[j]);
}
for(j=0;j<10;j++)
{ sum=sum+a[j];}
printf("sum of elements of array = %d",sum);
getch();
}