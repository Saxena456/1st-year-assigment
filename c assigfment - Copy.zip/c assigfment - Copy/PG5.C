#include<stdio.h>
#include<conio.h>
void main()
{
int a,b,c;
printf("enter the value of a and b");
clrscr();
scanf("%d %d",&a,&b);
printf("\nbefore swapping \na=%d \nb=%d",a,b);
c=a;
a=b;
b=c;
printf("\nafter swapping \na=%d \nb=%d",a,b);
getch();
}