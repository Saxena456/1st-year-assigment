#include<stdio.h>
#include<conio.h>
void main ()
{
int sum=0,n=1,r,nt=100,p;
clrscr();
printf("amrstrong numbers between 1-100 are --");
while(n<nt){
p=n;
while(n>0)
{r=n%10;
sum=sum+(r*r*r);
n=n/10;
}
if(sum==p){
printf("%d",sum);
break;}
n++;
}
getch();
}