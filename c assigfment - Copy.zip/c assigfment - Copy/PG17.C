#include<stdio.h>
#include<conio.h>
void main ()
{
int sum=0,n,p;
clrscr();
printf("enter the number");
scanf("%d",&n);
p=n;
while(n>0)
{sum=sum+(n%10);
n=n/10;
}
printf("sum of digits of %d=%d",p,sum);
getch();
}