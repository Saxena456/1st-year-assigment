#include<stdio.h>
#include<conio.h>
void main ()
{
int i,c=0,n;
printf("enter the number");
scanf("%d",&n);
for(i=2;i<=n/2;i++)
{ if(n%i==0){++c;}
}
if(c==0)
{printf("%d is a prime number",n);}
else{printf("%d is not a prime number",n);}
getch();
}