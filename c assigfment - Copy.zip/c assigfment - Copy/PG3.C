#include<stdio.h>
#include<conio.h>
void main()
{ float c,a,r;
printf("enter the radius");
scanf("%f",&r);
a=3.14*r*r;
c=2*3.14*r;
printf("\ncircumference=%f",c);
printf("\narea =%f",a);
getch();
}