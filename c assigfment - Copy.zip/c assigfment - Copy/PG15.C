#include<stdio.h>
#include<conio.h>
void main ()
{
int a=0,b=1,nxt,n;
printf("enter the number of terms in fibonacci series");
scanf("%d",&n);
while (n>0){
nxt=a+b;
printf("%2d",a);
a=b;
b=nxt;
n=n-1;}
getch();
}