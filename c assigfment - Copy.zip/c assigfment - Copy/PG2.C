#include<stdio.h>
#include<conio.h>
#include<math.h>
void main()
{ int prin;
float si,ci,r,t;
clrscr();
printf("enter the principle amount");
scanf("%d",&prin);
printf("enter the rate of interest");
scanf("%f",&r);
printf("enter the time in years");
scanf("%f",&t);
si=(prin*r*t)/100;
ci=(prin*(pow((1+(r/100)),t)))-prin;
printf("SIMPLE INTEREST=%f",si);
printf("\ncompound interest =%f",ci);
getch();
}