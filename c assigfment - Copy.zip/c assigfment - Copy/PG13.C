#include<stdio.h>
#include<conio.h>
void main()
{
int f=1,n,p;
clrscr();
printf("enter the number") ;
scanf("%d",&n);
p=n;
while(n>0){
f=f*n;
n=n-1;
}
printf("\nfactorial of %d=%d",p,f);
getch();

}