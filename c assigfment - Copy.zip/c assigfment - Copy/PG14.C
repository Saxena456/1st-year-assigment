#include<stdio.h>
#include<conio.h>
void main()
{
int i, sum=0,sum2=0,a,b,n;
printf("enter the nth term");
scanf("%d",&n);
for(i=0;i<=n;i++)
{
if(i%2==0){sum=sum+i;}
else{ sum2=sum2+i;}
}
printf("sum of even numbers till %d=%d\nsum of odd numbers till %d=%d",n,sum,n,sum2);
getch();
}