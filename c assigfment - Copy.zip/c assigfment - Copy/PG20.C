#include<stdio.h>
#include<conio.h>
#include<math.h>
void main()
{
long b;
int r,sum=0,c=0;
clrscr();
printf("enter the binary number");
scanf("%ld",&b);
while(b>0)
{
r=b%10;
sum=sum+(r*(pow(2,c)));
b=b/10;
++c;
}

printf("decimal vale=%d",sum);
getch();
}