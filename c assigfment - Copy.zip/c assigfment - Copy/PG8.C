#include<stdio.h>
#include<conio.h>
void main()
{
int a;
clrscr();
printf("enter  number");
scanf("%d",&a);
if(a%2==0){
printf(" entered number is even");
}
else {
printf("enetered number is odd");
}

getch();
}