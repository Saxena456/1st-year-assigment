#include<stdio.h>
#include<conio.h>
void main()
{  int che,phy,math,eng,hindi,total;
float avg,perc;
clrscr();
printf("enter the marks of 5 subject");
scanf("%d %d %d %d %d",&che,&phy,&math,&eng,&hindi);
total=che+phy+math+eng+hindi;
perc=((total*100)/500);
printf("%d",total);
printf("\nPercentage=%f",perc);
getch();
}
