#include<stdio.h>
#include<conio.h>
void main()
{
int a,b,c,d;
clrscr();
printf("enter two operands");
scanf("%d %d",&a,&b);
printf("\nchoose the operator \n1->+\n2->-\n3->*\n4->/\n");
scanf("%d",&c);
switch(c){
case 1:
printf("%d+%d=%d",a,b,a+b);
break;
case 2:
printf("%d-%d=%d",a,b,a-b);
break;
case 3:
printf("%d*%d=%d",a,b,a*b);
break;
case 4:
printf("%d/%d=%d",a,b,a/b);
break;
	  }
getch();

}