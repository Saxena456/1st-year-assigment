#include<stdio.h>
#include<conio.h>
void main()
{
int a;
clrscr();
printf("enter  number");
scanf("%d",&a);
if(a%400==0){
printf("yes, its a leap year");
}
else if(a%4==0 && a%100!=0) {
printf("yes, its a leap year");
}
else {
printf("no, its not a leap year");}

getch();
}