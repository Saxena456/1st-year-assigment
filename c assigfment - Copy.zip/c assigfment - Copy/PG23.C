#include<stdio.h>
#include<conio.h>
void main()
{
int a[10],j,max=0,min;
clrscr();
printf("enter the numbers");

for( j=0;j<10;j++)
{ scanf("%d",&a[j]);

}
min=a[0];
for(j=0;j<10;j++)
{ if(a[j]>max)
{max=a[j];}
if(a[j]<min)
{ min=a[j];}
}
printf("maximum=%d\nminnimum =%d",max,min);

getch();
}