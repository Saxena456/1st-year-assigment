#include<stdio.h>
#include<conio.h>
void main()
{
float f,c;
printf("Enter the temp in centigrade");
scanf("%f",&c);
f=(1.8*c)+32;
printf("temp in fahrenheit=%f",f);
getch();
}