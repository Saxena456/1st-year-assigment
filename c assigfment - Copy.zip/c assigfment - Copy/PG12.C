#include<stdio.h>
#include<conio.h>
void main()
{
int a,sum=0,i;
clrscr();
printf("enter the nth number");
scanf("%d",&a);
for(i=1;i<=a;i++) {
sum=sum+i;
}
printf("sum of all the numbers upto %d=%d",a,sum);
getch();

}